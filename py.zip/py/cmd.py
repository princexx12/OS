
#print 1-10 using for loop

numbers=5;

for num in numbers:
	print(num);
	
